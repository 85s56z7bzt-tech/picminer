# Picminer

方塊挖礦 + 拍照分享小遊戲。網站放在 GitHub Pages，登入和好友資料用 Firebase（免費方案）。

## 檔案
- `index.html`：整個遊戲（上傳到 GitHub）
- `firestore.rules`：資料庫安全規則（貼到 Firebase，不用上傳到 GitHub 也可以）

## 第一部分：設定 Firebase
1. 到 https://console.firebase.google.com 用 Google 帳號登入，按「建立專案」，名稱填 picminer。Google Analytics 可以關掉。
2. 專案建好後，在專案總覽按網頁圖示 `</>` 新增網頁應用程式，暱稱填 picminer，不要勾 Firebase Hosting，按註冊。
3. 畫面會出現一段 `const firebaseConfig = { ... }`。把大括號裡的內容複製，貼到 `index.html` 最上面的 `firebaseConfig`，取代原本的中文佔位文字。
4. 左側「建構」→「Authentication」→「開始使用」→「登入方式」：
   - 啟用「Google」（選一個支援用的 email，儲存）
   - 啟用「電子郵件/密碼」
5. 左側「建構」→「Firestore Database」→「建立資料庫」：位置選 `asia-east1`（台灣），模式選「正式版」。
6. 建好後到「規則」分頁，把 `firestore.rules` 的內容整個貼上，按「發布」。

## 第二部分：放上 GitHub Pages
1. 到 https://github.com 註冊帳號。帳號名稱會變成網址：`帳號名稱.github.io`。
2. 右上「+」→「New repository」：
   - 想要網址是 `https://帳號名稱.github.io` → repository 名稱填 `帳號名稱.github.io`
   - 想要網址是 `https://帳號名稱.github.io/picminer` → repository 名稱填 `picminer`
   - 選 Public，按 Create repository
3. 按「uploading an existing file」，把 `index.html` 拖進去，按「Commit changes」。
4. 到 repository 的「Settings」→ 左側「Pages」→ Source 選「Deploy from a branch」，Branch 選 `main`、資料夾選 `/ (root)`，按 Save。等 1～2 分鐘，上方會出現網址。

## 第三部分：讓登入可以用
回到 Firebase →「Authentication」→「設定」→「授權網域」→「新增網域」，填 `帳號名稱.github.io`（不用加 https 和 /picminer）。

## 之後要更新
在 GitHub 的 repository 按「Add file」→「Upload files」，上傳新的 `index.html`（同檔名會直接覆蓋），按 Commit，等 1～2 分鐘就更新了。
